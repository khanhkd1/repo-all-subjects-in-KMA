package KeThuaDaHinhTruuTuong.Bai1;

public class Main {
    public static void main(String[] args) {
        HinhChuNhat hcn = new HinhChuNhat();
        HinhVuong hv = new HinhVuong();
        hcn.nhap();
        hv.nhap();
        hcn.xuat();
        hv.xuat();
    }
}
