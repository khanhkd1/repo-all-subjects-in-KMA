package KeThuaDaHinhTruuTuong.Bai1;


public class Hinh {
    public double tinhChuVi(){
        return 0;
    }
    public double tinhDienTich(){
        return 0;
    }
    public void nhap(){

    }

    public void xuat(){

    }
}
