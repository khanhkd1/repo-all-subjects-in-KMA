<html>
    <head>
        <meta charset="UTF-8">
        <title></title>
    </head>
    <body>
        <form action="index.php" method="post">
            <h1>Form ve bang</h1>
            <div>
                <label>So dong: </label>
                <input type="number" name="sodong" size="10" />
            </div>
            <div>
                <label>So cot: </label>
                <input type="number" name="socot" size="10" />
            </div>
            <div>
                <input type="reset" name="del" value="Nhap lai"/>
                <input type="submit" name="add" value="Ve"/>
            </div>
        </form>
    </body>
</html>
