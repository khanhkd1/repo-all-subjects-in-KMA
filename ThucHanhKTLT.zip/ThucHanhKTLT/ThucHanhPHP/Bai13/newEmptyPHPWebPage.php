<html>
    <head>
        <meta charset="UTF-8">
        <title></title>
    </head>
    <body>
        <form action="index.php" method="post">
            <h1>Form Dang Ky</h1>
            <div>
                <label>Ten: </label>
                <input type="text" name="ten" size="45" />
            </div>
            <div>
                <label>Dia chi: </label>
                <input type="text" name="diachi" size="45" />
            </div>
            <div>
                <label>Nghe: </label>
                <input type="text" name="nghe" size="45" />
            </div>
            <div>
                <label>Ghi chu: </label>
                <input type="text" name="ghichu" size="45" />
            </div>
            <div>
                <input type="reset" name="del" value="Xoa"/>
                <input type="submit" name="add" value="Dang Ky"/>
            </div>
        </form>
    </body>
</html>
